groups = {
    #Característica: Nombre de jugador
    "Nombre":"""Cristiano Ronaldo Dos Santos Aveiro, 
            Lionel Andrés Messi Cuccittini, 
            Edson Arantes do Nascimento, 
            Diego Armando Maradona,
            Hendrik Johannes Cruijff,
            Zinédine Yazid Zidane,
            Franz Anton Albert Beckenbauer,
            Alfredo Stéfano Di Stéfano Laulhé,
            Ronaldo Luís Nazário de Lima,
            Ronald Samuel"""

    #Característica: Nacionalidad de Jugador
        "Apodo""""Portugal, 
            Argentina, 
            Brasil, 
            Argentina,
            Holanda,
            Francia,
            Alemania,
            Argentina y Español,
            Brasil,
            Inglaterra"""

    #Característica: Dorsal de jugador
    "Dorsal""""7, 
            10, 
            10, 
            10,
            14,
            5,
            6,
            9,
            9,
            7"""

    #Característica: Goles
    "Goles""""El Bicho, 
            La Pulga, 
            El Rey, 
            Pelusa,
            El Tulipán de Oro,
            Zizou,
            El Káiser,
            La Saeta Rubia,
            El Fenómeno,
            El Chico de Belfast"""

    #Característica: Asistencias
    "Asistecias""""El Bicho, 
            La Pulga, 
            El Rey, 
            Pelusa,
            El Tulipán de Oro,
            Zizou,
            El Káiser,
            La Saeta Rubia,
            El Fenómeno,
            El Chico de Belfast"""
}


groupdefs = {
'Nombre': 'Son los nombres originales con los cuales estan registrados en su pais natal', 
'Apodo': 'Son los nombres con los cuales son reconocidos a nivel mundial',
'dorsal': 'Son los numeros con los cuales habitualmente juegan estos jugadores',
'Goles': 'Es el numero de goles los cuales han anotado a lo largo de su carrera',
'Asistencias': 'Es el numero de asistencias las cuales han hecho a lo largo de su carrera'
}